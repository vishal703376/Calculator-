const app = document.getElementById("app");

let username = "";
let currentQuestion = 0;
let score = 0;

const questions = [
  { q: "What is 2 + 2?", options: ["2", "4", "6", "8"], answer: "4" },
  { q: "Capital of France?", options: ["Rome", "Paris", "London", "Berlin"], answer: "Paris" },
  { q: "Largest planet?", options: ["Earth", "Venus", "Jupiter", "Mars"], answer: "Jupiter" },
  { q: "HTML stands for?", options: ["Hyper Text Makeup", "Hyper Text Markup", "Home Tool Markup", "None"], answer: "Hyper Text Markup" },
  { q: "CSS used for?", options: ["Layout", "Logic", "Database", "All"], answer: "Layout" },
  { q: "JavaScript is a ___ language.", options: ["Markup", "Programming", "Query", "Styling"], answer: "Programming" },
  { q: "Full form of JS?", options: ["Java", "Just Script", "JavaScript", "JsonScript"], answer: "JavaScript" },
  { q: "Which is a frontend framework?", options: ["MongoDB", "Express", "React", "Node.js"], answer: "React" },
  { q: "Which keyword for variable?", options: ["set", "let", "var", "both let & var"], answer: "both let & var" },
  { q: "Git is used for?", options: ["Hosting", "Coding", "Version Control", "Testing"], answer: "Version Control" },
];

function showWelcome() {
  app.innerHTML = `
    <h1 class="text-3xl font-bold text-indigo-700">Welcome to the Quiz!</h1>
    <p class="text-lg text-gray-700">Enter your name to begin:</p>
    <input id="nameInput" type="text" class="mt-4 p-2 w-full border rounded-md" placeholder="Your name" />
    <button onclick="startRules()" class="mt-4 px-6 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Next</button>
  `;
}

function startRules() {
  const input = document.getElementById("nameInput");
  if (!input.value.trim()) return alert("Please enter your name.");
  username = input.value.trim();
  app.innerHTML = `
    <h2 class="text-2xl font-bold text-purple-700">Hi, ${username}!</h2>
    <p class="text-gray-700 mt-4">Quiz Rules:</p>
    <ul class="text-left mt-2 list-disc list-inside text-gray-600">
      <li>10 questions total</li>
      <li>Each question has 4 options</li>
      <li>Only one correct answer</li>
      <li>Score shown at the end</li>
    </ul>
    <button onclick="startQuiz()" class="mt-6 px-6 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700">Start Quiz</button>
  `;
}

function startQuiz() {
  currentQuestion = 0;
  score = 0;
  showQuestion();
}

function showQuestion() {
  const q = questions[currentQuestion];
  app.innerHTML = `
    <h2 class="text-xl font-semibold text-indigo-800">Q${currentQuestion + 1}. ${q.q}</h2>
    <div class="grid grid-cols-2 gap-4 mt-6">
      ${q.options.map(opt => `
        <button onclick="checkAnswer('${opt}')" class="px-4 py-2 bg-gray-100 hover:bg-indigo-100 rounded-lg">${opt}</button>
      `).join("")}
    </div>
    <p class="mt-6 text-gray-600">Score: ${score}</p>
  `;
}

function checkAnswer(selected) {
  const correct = questions[currentQuestion].answer;
  if (selected === correct) score++;

  currentQuestion++;
  if (currentQuestion < questions.length) {
    showQuestion();
  } else {
    showFinalScore();
  }
}

function showFinalScore() {
  app.innerHTML = `
    <h2 class="text-2xl font-bold text-green-700">Congratulations, ${username}!</h2>
    <img src="trophy_78370-345.avif" class="w-32 mx-auto my-4" alt="Trophy"/>
    <p class="text-xl text-gray-800">Your Score: <span class="font-bold">${score}/10</span></p>
    <hr>
    <h4 class="text-gray-600 mt-2 font-bold text-black-700">Thank you for playing!</h4>
    <button onclick="showWelcome()" class="mt-6 px-6 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Play Again</button>
  `;
}



// Initialize
showWelcome();
